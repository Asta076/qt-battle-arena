Monster sprite sheets generated from your GIFs

Frame size: 68x68
Movement sheets: 8 columns x 9 rows
  Row 0 = idle poses, columns 0-7
  Rows 1-8 = walking directions, 6 frames in columns 0-5
Attack sheets: 7 columns x 8 rows
  Rows 0-7 = attack directions, 7 frames in columns 0-6

Direction order used in both sheets:
0 south
1 south-east
2 east
3 north-east
4 north
5 north-west
6 west
7 south-west

Note: the plain goblin archive had no south-west walking GIF, so I mirrored south-east for that row.
